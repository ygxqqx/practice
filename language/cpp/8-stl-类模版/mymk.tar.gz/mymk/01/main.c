#include "stdio.h"
int main()
{
	int i = 0;
	int j = 11;
	printf("hello:%d \n", i);
	return 0;


}



